/**
 * 
 */
package com.trantor.leavesys.service.api;

import com.trantor.leavesys.models.UserModel;

/**
 * @author rajni.ubhi
 *
 */
public interface IUserService {
	public UserModel getUserModel(UserModel userModel);
}
