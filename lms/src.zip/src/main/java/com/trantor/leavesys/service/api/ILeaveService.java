/**
 * 
 */
package com.trantor.leavesys.service.api;

import java.util.List;

import com.trantor.leavesys.models.LeaveModel;

/**
 * @author rajni.ubhi
 *
 */
public interface ILeaveService {
	public List<LeaveModel> getAllLeaves();
}
