/**
 * 
 */
package com.trantor.leavesys.entities;

/**
 * @author rajni.ubhi
 *
 */
public enum LeaveStatus {
	APPROVED, NOT_APPROVED , CANCELLED
}
