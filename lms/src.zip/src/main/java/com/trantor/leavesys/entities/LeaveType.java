package com.trantor.leavesys.entities;

public enum LeaveType {
	CL,EL,PL,SL
}
